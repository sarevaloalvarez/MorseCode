import java.io.*;
public class morse {
    public static String[] alphabet = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j",
    "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v",
    "w", "x", "y", "z", "1", "2", "3", "4", "5", "6", "7", "8",
    "9", "0"};
    public static String[] morseCodes = { ".-", "-...", "-.-.", "-..", ".", "..-.", "--.",
    "....", "..", ".---", "-.-", ".-..", "--", "-.", "---", ".--.",
    "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-",
    "-.--", "--..", ".----", "..---", "...--", "....-", ".....",
    "-....", "--...", "---..", "----.", "-----"};
    public static BufferedWriter out;    
    public static void main(String[] args)throws IOException{ 
        out=new BufferedWriter(new FileWriter("Permutations.txt"));
        decrypt("","-.-.....-.-.........",0);
        out.close();
    }

    public static void decrypt(String prev,String code, int i)throws IOException{
        if(code.length()==i){
            //writes the permutation into a text file
            out.write((eliminate(prev+traverse(code))));
        }
        else if(code.length()<i){return;}
        else{
            prev+=traverse(code.substring(0,i));
            for(int j=1;j<=5;j++){
                decrypt(prev,code.substring(i),j);
            }
        }
    }

    // traverses through morse code array and returns matching index of the alphabet array
    public static String traverse(String codeFrag){
        for (int i=0;i<36;i++){
            if (morseCodes[i].equals(codeFrag)){return alphabet[i];}  
        }
        //if "?" is added it will later be eliminated
        return "?";
    }

    //eliminates any permutation that contains a ? after the first index
    public static String eliminate(String perm){
        for (int i=1;i<perm.length();i++){if(perm.charAt(i)=='?'){return "";}}
            return perm.substring(1)+"\n";
    }
    
    
}